package com.example.miniprojectakthemmalek.Model.callbackInterfaces;

import com.example.miniprojectakthemmalek.Model.entities.User;

import java.util.List;

public interface ICallbackService {

    public void onResponse(List<User> response);

}
