package com.example.miniprojectakthemmalek;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.miniprojectakthemmalek.Model.callbackInterfaces.ICallbackService;
import com.example.miniprojectakthemmalek.Model.entities.User;
import com.example.miniprojectakthemmalek.Model.repositories.UserRepository;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    UserRepository userRepository;
EditText username,password;
Button add;
List<User> userList=new ArrayList<User>();

    String URL="http://192.168.1.7:3003/users/getAll";
    String POST_URL="http://192.168.1.7:3003/users/add";
    String PUT_URL="http://192.168.1.7:3003/users/update";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        add=findViewById(R.id.add);
        userRepository =new UserRepository();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               User user=new User(username.getText().toString(),password.getText().toString());
                //userRepository.add(user,POST_URL,getApplicationContext());
              //  userRepository.update(user,PUT_URL,getApplicationContext());
                userRepository.delete(username.getText().toString(),getApplicationContext());

            }
        });

     /*   UserRepository.getAll(URL, this, new ICallbackService() {

            @Override
            public void onResponse(List<User> response) {
               System.out.println(response);
            }
            @Override
            public void onOneResponse(User response) {
            }
        });
*/
        UserRepository.getOne("test1",this,new ICallbackService(){

            @Override
            public void onResponse(List<User> response) {
                System.out.println(response);
            }

        });

    }
}
