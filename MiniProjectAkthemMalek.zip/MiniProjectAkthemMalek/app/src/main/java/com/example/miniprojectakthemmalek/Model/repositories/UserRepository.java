package com.example.miniprojectakthemmalek.Model.repositories;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.miniprojectakthemmalek.Model.callbackInterfaces.ICallbackService;
import com.example.miniprojectakthemmalek.Model.entities.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class UserRepository {

public static void getAll(String URL, Context context, final ICallbackService iCallbackService)
    {

        RequestQueue  requestQueue = Volley.newRequestQueue(context);
        StringRequest stringRequest =new StringRequest(Request.Method.GET,URL,


                new Response.Listener<String>(){

                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONArray users = new JSONArray(response);
                            List<User> userList=new ArrayList<User>();

                            for(int i=0;i<users.length();i++)
                            {
                                JSONObject userJSONObject = users.getJSONObject(i);
                                User user=new User(Integer.parseInt(userJSONObject.get("id").toString()),userJSONObject.get("username").toString(),userJSONObject.get("password").toString(),userJSONObject.get("email").toString(),userJSONObject.get("first_name").toString(),userJSONObject.get("last_name").toString(),userJSONObject.get("address").toString());

                                if(!userJSONObject.get("phone_number").toString().equals("null"))
                                {
                                    user.setPhone_number(Long.parseLong(userJSONObject.get("phone_number").toString()));
                                }

                                if(!userJSONObject.get("isActive").toString().equals("null"))
                                {
                                    user.setActive(Boolean.parseBoolean(userJSONObject.get("isActive").toString()));
                                }

                                userList.add(user);

                                iCallbackService.onResponse(userList);
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                }, new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(stringRequest);

    }

    public void add(final User user, String URL, Context context)  {

        RequestQueue  requestQueue = Volley.newRequestQueue(context);
        JSONObject userparams = new JSONObject();
        try {

            userparams.put("username",user.getUsername());
            userparams.put("password",user.getPassword());
            userparams.put("email",user.getEmail());
            userparams.put("first_name",user.getFirst_name());
            userparams.put("last_name",user.getLast_name());
            userparams.put("phone_number",user.getPhone_number());
            userparams.put("address",user.getAddress());
            userparams.put("isActive",user.isActive());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest userJsonRequest= new JsonObjectRequest(Request.Method.POST, URL, userparams,null,null);
        requestQueue.add(userJsonRequest);
    }

public void update(final User user, String URL, Context context)  {

        RequestQueue  requestQueue = Volley.newRequestQueue(context);
        JSONObject userparams = new JSONObject();
        try {

            userparams.put("username",user.getUsername());
            userparams.put("password",user.getPassword());
            userparams.put("email",user.getEmail());
            userparams.put("first_name",user.getFirst_name());
            userparams.put("last_name",user.getLast_name());
            userparams.put("phone_number",user.getPhone_number());
            userparams.put("address",user.getAddress());
            userparams.put("isActive",user.isActive());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest userJsonRequest= new JsonObjectRequest(Request.Method.PUT, URL, userparams,null,null);
        requestQueue.add(userJsonRequest);

}


public static void getOne(final String username, Context context, final ICallbackService iCallbackService)  {

    String URL="http://192.168.1.7:3003/users/get/"+username;

    RequestQueue  requestQueue = Volley.newRequestQueue(context);
    StringRequest stringRequest =new StringRequest(Request.Method.GET,URL,

                new Response.Listener<String>(){

                    @Override
                    public void onResponse(String response) {

                        List<User> userList=new ArrayList<User>();

                            try {
                                JSONArray users = new JSONArray(response);

                                for (int i=0;i<users.length();i++)
                                {
                                JSONObject userJSONObject = users.getJSONObject(i);
                                User user=new User(userJSONObject.get("username").toString(),userJSONObject.get("password").toString());
                                userList.add(user);
                                }

                            } catch (JSONException ex) {
                                ex.printStackTrace();
                            }

                                iCallbackService.onResponse(userList);

                            }

                }, new Response.ErrorListener(){

            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(stringRequest);
    };

    public void delete(String username, Context context)  {

        String DELETE_URL="http://192.168.1.7:3003/users/delete/"+username;

        RequestQueue  requestQueue = Volley.newRequestQueue(context);
        StringRequest userJsonRequest= new StringRequest(Request.Method.DELETE,DELETE_URL,null,null);
        requestQueue.add(userJsonRequest);
    }

}









